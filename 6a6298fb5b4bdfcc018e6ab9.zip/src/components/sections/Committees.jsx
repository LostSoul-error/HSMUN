const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useRef } from "react";
import { motion, useInView } from "framer-motion";
import Reveal from "@/components/Reveal";
import { Image } from "@/components/ui/image";

const COMMITTEES = [
  {
    name: "AIPPM",
    full: "All India Political Party Meet",
    agenda: "One Nation, One Election — Reforming the Democratic Machinery",
    desc: "A dynamic parliamentary simulation where delegates represent political parties and negotiate the future of Indian democracy.",
    image: "https://media.db.com/images/public/6a6298fb5b4bdfcc018e6ab9/7e95560b2_generated_78840b85.png",
    hue: "from-emerald-900/60 to-forest-deep",
  },
  {
    name: "DISEC",
    full: "Disarmament & International Security",
    agenda: "Disarmament & International Security — Mitigating the Proliferation of Autonomous Weaponry",
    desc: "The First Committee of the UN General Assembly, tackling global security and the ethics of modern warfare.",
    image: "https://media.db.com/images/public/6a6298fb5b4bdfcc018e6ab9/7db8faaba_generated_9a57f99f.png",
    hue: "from-teal-900/60 to-forest-deep",
  },
  {
    name: "UNHRC",
    full: "United Nations Human Rights Council",
    agenda: "Safeguarding Human Rights in the Era of Climate Displacement",
    desc: "Defending the dignity of humanity — delegates address the world's most urgent humanitarian crises.",
    image: "https://media.db.com/images/public/6a6298fb5b4bdfcc018e6ab9/5e2aa79db_generated_0e3f12f5.png",
    hue: "from-cyan-900/50 to-forest-deep",
  },
  {
    name: "ICC",
    full: "International Criminal Court",
    agenda: "Prosecuting Crimes Against Humanity in Conflict Zones",
    desc: "A courtroom simulation of justice — where delegates argue law, evidence, and accountability on the world stage.",
    image: "https://media.db.com/images/public/6a6298fb5b4bdfcc018e6ab9/09dde6503_generated_ccf758fd.png",
    hue: "from-amber-950/50 to-forest-deep",
  },
];

function CommitteeCard({ c, index }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-8% 0px" });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 70, filter: "blur(16px)" }}
      animate={inView ? { opacity: 1, y: 0, filter: "blur(0px)" } : {}}
      transition={{ duration: 1, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
      className="group relative rounded-3xl overflow-hidden glass min-h-[440px] flex flex-col justify-end"
    >
      <Image
        src={c.image}
        alt={c.name}
        fittingType="fill"
        className="absolute inset-0 w-full h-full transition-transform duration-[1.2s] ease-out group-hover:scale-110"
      />
      <div className={`absolute inset-0 bg-gradient-to-t ${c.hue} via-forest-deep/70 to-transparent`} />
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-[radial-gradient(circle_at_50%_30%,rgba(212,175,55,0.18),transparent_60%)]" />

      <div className="relative z-10 p-7 md:p-9">
        <p className="font-micro uppercase tracking-[0.3em] text-gold-champagne text-[10px] mb-2">{c.full}</p>
        <h3 className="font-display gold-text text-4xl md:text-5xl mb-4">{c.name}</h3>
        <p className="font-body text-parchment/80 text-sm leading-relaxed mb-2">{c.desc}</p>
        <div className="overflow-hidden transition-all duration-500 max-h-0 opacity-0 group-hover:max-h-32 group-hover:opacity-100">
          <div className="pt-3 mt-3 border-t border-gold-imperial/25">
            <p className="font-micro uppercase tracking-[0.2em] text-gold-light text-[10px] mb-1">Agenda</p>
            <p className="font-heading italic text-parchment/90 text-sm leading-snug">{c.agenda}</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export default function Committees() {
  return (
    <section className="relative min-h-screen w-full flex items-center py-24 md:py-32 overflow-hidden bg-gradient-to-b from-forest-deep via-forest-surface to-forest-deep">
      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 w-full">
        <div className="text-center mb-16">
          <Reveal variant="fade-up">
            <p className="font-micro uppercase tracking-[0.4em] text-gold-champagne/70 text-[11px] mb-4">— The Core Experience</p>
          </Reveal>
          <Reveal variant="blur" delay={0.1}>
            <h2 className="font-heading text-4xl md:text-6xl text-parchment">The <span className="gold-text font-display">Committees</span></h2>
          </Reveal>
        </div>
        <div className="grid md:grid-cols-2 gap-6 md:gap-8">
          {COMMITTEES.map((c, i) => (
            <CommitteeCard key={c.name} c={c} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}