import React, { useRef } from "react";
import { motion, useInView } from "framer-motion";
import Reveal from "@/components/Reveal";
import { Camera, Mic, Newspaper, PenTool } from "lucide-react";

const PRESS = [
  { icon: Newspaper, title: "The Daily Communiqué", desc: "Live coverage of resolutions, crises, and the diplomatic theatre unfolding across committees." },
  { icon: Camera, title: "Lens & Light", desc: "Photojournalism capturing the gravity and brilliance of every delegate's moment." },
  { icon: Mic, title: "On the Record", desc: "Interviews with chairs, delegates, and the voices shaping the conference." },
  { icon: PenTool, title: "Editorial Desk", desc: "Opinion pieces and analysis — the conscience of HSMUN in print." },
];

function PressCard({ item, index }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-10% 0px" });
  const Icon = item.icon;
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50, rotate: index % 2 ? 2 : -2 }}
      animate={inView ? { opacity: 1, y: 0, rotate: 0 } : {}}
      transition={{ duration: 0.9, delay: index * 0.14, ease: [0.22, 1, 0.36, 1] }}
      className="group"
    >
      <div className="glass rounded-2xl p-8 h-full transition-all duration-500 group-hover:-translate-y-2 group-hover:rotate-[0.5deg] group-hover:border-gold-champagne/60">
        <div className="relative mb-5">
          <div className="w-14 h-14 rounded-xl glass-strong flex items-center justify-center">
            <Icon className="w-6 h-6 text-gold-imperial" />
          </div>
        </div>
        <h3 className="font-heading text-2xl text-parchment mb-2">{item.title}</h3>
        <p className="font-body text-parchment/65 text-sm leading-relaxed">{item.desc}</p>
      </div>
    </motion.div>
  );
}

export default function InternationalPress() {
  return (
    <section className="relative min-h-screen w-full flex items-center py-24 md:py-32 overflow-hidden">
      {/* paper texture overlay */}
      <div className="absolute inset-0 opacity-[0.04] bg-[repeating-linear-gradient(0deg,transparent,transparent_3px,#D4AF37_3px,#D4AF37_4px)]" />
      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 w-full">
        <div className="text-center mb-16">
          <Reveal variant="fade-up">
            <p className="font-micro uppercase tracking-[0.4em] text-gold-champagne/70 text-[11px] mb-4">— The Fourth Estate</p>
          </Reveal>
          <Reveal variant="blur" delay={0.1}>
            <h2 className="font-heading text-4xl md:text-6xl text-parchment">International <span className="gold-text font-display">Press</span></h2>
          </Reveal>
          <Reveal variant="fade" delay={0.2}>
            <p className="font-heading italic text-parchment/60 text-lg mt-4">Every word recorded. Every voice immortalised.</p>
          </Reveal>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {PRESS.map((p, i) => (
            <PressCard key={p.title} item={p} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}