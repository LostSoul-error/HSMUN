import React from "react";
import { Instagram, Mail, MapPin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="relative w-full overflow-hidden border-t border-gold-imperial/15">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-forest-surface/40" />
      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 py-14">
        <div className="glass-strong rounded-2xl px-8 py-10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="text-center md:text-left">
              <h3 className="font-display gold-text text-3xl">HSMUN 2026</h3>
              <p className="font-heading italic text-parchment/60 text-sm mt-1">Where Leaders Debate. Diplomats Rise.</p>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-6">
              <a
                href="https://instagram.com/hsmun2026"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 font-micro uppercase tracking-[0.2em] text-[11px] text-parchment/70 hover:text-gold-light transition-colors min-h-[44px]"
              >
                <Instagram className="w-4 h-4" /> Instagram
              </a>
              <a
                href="mailto:contact@hsmun2026.com"
                className="flex items-center gap-2 font-micro uppercase tracking-[0.2em] text-[11px] text-parchment/70 hover:text-gold-light transition-colors min-h-[44px]"
              >
                <Mail className="w-4 h-4" /> Email
              </a>
              <span className="flex items-center gap-2 font-micro uppercase tracking-[0.2em] text-[11px] text-parchment/70 min-h-[44px] flex items-center">
                <MapPin className="w-4 h-4" /> Hem Sheela, Dehradun
              </span>
            </div>
          </div>

          <div className="mt-10 pt-8 border-t border-gold-imperial/10 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="font-micro uppercase tracking-[0.2em] text-parchment/40 text-[10px]">
              © 2026 Hem Sheela Model United Nations
            </p>
            <p className="font-micro uppercase tracking-[0.2em] text-parchment/40 text-[10px]">
              Designed with <span className="text-gold-imperial">❤</span> by the HSMUN Tech Bureau
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}