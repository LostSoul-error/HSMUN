import React, { useRef } from "react";
import { motion, useInView } from "framer-motion";
import Reveal from "@/components/Reveal";
import ParticleCanvas from "@/components/ParticleCanvas";

const MEMBERS = [
  { name: "Secretary General", position: "Secretary General", desc: "The steward of the conference, presiding over all diplomatic proceedings." },
  { name: "Director General", position: "Director General", desc: "Architect of operations, ensuring the machinery of HSMUN runs flawlessly." },
  { name: "Charge d'Affaires", position: "Charge d'Affaires", desc: "Bridging delegates and the secretariat with grace and authority." },
  { name: "Treasurer", position: "Treasurer", desc: "Custodian of resources, the financial conscience of the conference." },
  { name: "Head of IP", position: "Head of International Press", desc: "Curating the narrative of HSMUN across every committee." },
  { name: "USG Logistics", position: "USG Logistics", desc: "The invisible hand that orchestrates the diplomatic symphony." },
];

function PortraitCard({ member, index }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-10% 0px" });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 60, filter: "blur(12px)" }}
      animate={inView ? { opacity: 1, y: 0, filter: "blur(0px)" } : {}}
      transition={{ duration: 0.9, delay: index * 0.12, ease: [0.22, 1, 0.36, 1] }}
      className="group relative"
    >
      <div className="glass rounded-2xl p-6 h-full transition-all duration-500 group-hover:-translate-y-2 group-hover:border-gold-champagne/60 group-hover:shadow-[0_20px_60px_rgba(212,175,55,0.18)]">
        {/* portrait placeholder */}
        <div className="relative w-full aspect-[3/4] rounded-xl overflow-hidden mb-5 bg-gradient-to-br from-forest-surface to-forest-deep">
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="font-display gold-text text-5xl opacity-80">
              {member.position.split(" ").map((w) => w[0]).join("").slice(0, 2)}
            </span>
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-forest-deep/80 via-transparent to-transparent" />
          {/* flash refraction streak */}
          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-[linear-gradient(105deg,transparent_40%,rgba(242,217,141,0.18)_50%,transparent_60%)]" />
        </div>
        <p className="font-micro uppercase tracking-[0.25em] text-gold-champagne text-[10px] mb-1">{member.position}</p>
        <h3 className="font-heading text-xl text-parchment">{member.name}</h3>
        <p className="font-body text-parchment/60 text-sm leading-relaxed mt-2">{member.desc}</p>
      </div>
    </motion.div>
  );
}

export default function Secretariat() {
  return (
    <section className="relative min-h-screen w-full flex items-center py-24 md:py-32 overflow-hidden">
      <ParticleCanvas density={35} />
      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 w-full">
        <div className="text-center mb-16">
          <Reveal variant="fade-up">
            <p className="font-micro uppercase tracking-[0.4em] text-gold-champagne/70 text-[11px] mb-4">— The Faces of Power</p>
          </Reveal>
          <Reveal variant="blur" delay={0.1}>
            <h2 className="font-heading text-4xl md:text-6xl text-parchment">The <span className="gold-text font-display">Secretariat</span></h2>
          </Reveal>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {MEMBERS.map((m, i) => (
            <PortraitCard key={m.position} member={m} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}